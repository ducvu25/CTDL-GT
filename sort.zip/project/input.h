#include <iostream>
#include <fstream>
#include <time.h>
using namespace std;
void KhoiTao(char* s, int n, int max, int min);
int* Input(char* s, int& n);
void Cout(int* a, int n);