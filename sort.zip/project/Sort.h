#include <iostream>

using namespace std;

void SelectionSort(int* a, int n, bool tangDan);
void InterchangerSort(int* a, int n, bool tangDan);
void InsertionSort(int* a, int n, bool tangDan);
void BubbleSort(int* a, int n, bool tangDan);
void Mega(int* a, int left, int mid, int right, bool tangDan);
void MegaSort(int* a, int left, int right, bool tangDan);
int Quick(int* a, int left, int right, bool tangDan);
void QuickSort(int* a, int left, int right, bool tangDan);
