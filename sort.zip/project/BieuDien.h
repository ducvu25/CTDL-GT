#include "DoThi.h"

void SelectionSortDT(int* a, int n);
void InterchangerSortDT(int* a, int n, bool tangDan);
void InsertionSortDT(int* a, int n, bool tangDan);
void BubbleSortDT(int* a, int n, bool tangDan);
void MegaDT(int* a, int left, int mid, int right, bool tangDan);
void MegaSortDT(int* a, int left, int right, bool tangDan);
int QuickDT(int* a, int left, int right, bool tangDan);
void QuickSortDT(int* a, int left, int right, bool tangDan);
