#include <Windows.h>
#include <iostream>

#define setColorX 11
#define setColorY 14
#define setColorN 15
#define setColorMin 13
#define setX 30
#define setY 17
#define timeDelete 100
#define timeStop 200
void TextColor(int color);
void gotoXY(int i, int j);
void DoThi(int* a, int n, int x, int y, int min, int d);